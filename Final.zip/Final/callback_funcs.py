def password_click(x, y):
	result = False

	if y >= 450:
		if y <= 505:
			if x <= 125:
				result = '1'
			elif x <= 250:
				result = '2'
			else:
				result = '3'
		elif y <= 560:
			if x <= 125:
				result = '4'
			elif x <= 250:
				result = '5'
			else:
				result = '6'
		elif y <= 615:
			if x <= 125:
				result = '7'
			elif x <= 250:
				result = '8'
			else:
				result = '9'
		else:
			if x > 125 and x <= 250:
				result = '0'
			elif x > 250:
				result = 'delete'
	
	return result

def password_key(char):
	if char == 'BackSpace':
		result = 'delete'
	elif char in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']:
		result = char
	else:
		result = False

	return result

def balance_key(char):
	if char == 'BackSpace':
		result = 'delete'
	elif char == 'Return':
		result = 'enter'
	elif char == 'period':
		result = '.'
	elif char in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']:
		result = char
	else:
		result = False

	return result

def password_alert_click(x, y):
	if x >= 52 and x <= 322 and y >= 290 and y <= 335:
		result = 'close'
	else:
		result = False

	return result

def menu_click(x, y):
	if y >= 233 and y <= 278:
		result = 'balance'
	elif y >= 289 and y <= 332:
		result = 'withdraw'
	elif y >= 345 and y <= 388:
		result = 'topup'
	elif y >= 533 and y <= 574:
		result = 'home'
	else:
		result = False

	return result

def topup_click(x, y):
	if y >= 20 and y <= 65 and x <= 80:
		result = 'prev'
	else:
		result = False

	return result

def topup_success_click(x, y):
	if x >= 52 and x <= 322 and y >= 308 and y <= 349:
		result = 'prev'
	else:
		result = False

	return result

def withdraw_success_click(x, y):
	if x >= 52 and x <= 322 and y >= 307 and y <= 348:
		result = 'prev'
	else:
		result = False

	return result

def withdraw_alert_click(x, y):
	if x >= 52 and x <= 322 and y >= 290 and y <= 334:
		result = 'again'
	else:
		result = False
	
	return result
