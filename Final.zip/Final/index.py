from Tkinter import *

import os
import time
import callback_funcs as callback
import coder_funcs as coder

class Controller:

	root = None
	cwd  = os.getcwd()

	width  = 375
	height = 667

	windows = None

	current_section = 'Password'
	prev_section = 'Password'
	home_section = 'Password'

	card_href = 'pavel.card'
	secret_code = 'ATM89230124'

	balance = 56.6

	# Section variables
	# Password
	true_password = '1234'
	password = ''

	def __init__(self):

		self.root = Tk()

		self.root.wm_title("ATM")

		self.root.bind("<Key>", self.key_callback)
		self.root.bind("<Button-1>", self.click_callback)

	def raise_window(self, window_name):

		self.windows[window_name].frame.tkraise()

	def key_callback(self, event):

		if self.current_section == 'Password':

			result = callback.password_key(event.keysym)

			if result != 'delete' and len(self.password) >= 4:
				return

			self.edit_password(result)

		elif self.current_section == 'Topup' or self.current_section == 'Withdraw':

			if self.current_section == 'Topup':
				text_field = topup0
			else:
				text_field = withdraw0

			result = callback.balance_key(event.keysym)

			if result == 'delete':

				_str = text_field.entry.get()[:len(text_field.entry.get())-1]

				text_field.entry.delete(0, END)
				text_field.entry.insert(0, _str)

			elif result == 'enter':

				self.submit_value()

			elif result != False:

				floatStr = ''
				intStr = ''

				inStr = text_field.entry.get() + result

				try:
					floatStr = str(round(float(inStr), 2))
				except:
					pass

				try:	
					intStr = str(int(inStr))
				except:
					pass

				if inStr == floatStr or inStr == intStr or inStr == floatStr[:len(floatStr)-1]:
					text_field.entry.delete(0, END)
					text_field.entry.insert(0, inStr)


	def click_callback(self, event):

		if self.current_section == 'Password':

			result = callback.password_click(event.x, event.y)

			if result != 'delete' and len(self.password) >= 4:
				return

			self.edit_password(result)

		elif self.current_section == 'Password_alert':

			result = callback.password_alert_click(event.x, event.y)

			if result == 'close':
				self.go('home')

		elif self.current_section == 'Menu':

			result = callback.menu_click(event.x, event.y)

			if result == 'home':
				self.go('home')
			elif result == 'balance':
				self.prev_section = 'Menu'
				self.current_section = 'Balance'
				balance0.balance_label.config(text='%.2f PLN' % self.balance)
				self.raise_window('Balance0')
			elif result == 'topup':
				self.prev_section = 'Menu'
				self.current_section = 'Topup'
				self.raise_window('Topup0')
			elif result == 'withdraw':
				self.prev_section = 'Menu'
				self.current_section = 'Withdraw'
				self.raise_window('Withdraw0')

		elif self.current_section == 'Topup':

			result = callback.topup_click(event.x, event.y)

			if result == 'prev':
				topup0.entry.delete(0, END)
				self.go('prev')
				return

			result = callback.password_click(event.x, event.y)

			if result == False:

				return

			elif result == 'delete':

				_str = topup0.entry.get()[:len(topup0.entry.get())-1]

				topup0.entry.delete(0, END)
				topup0.entry.insert(0, _str) 

			else:

				_str = topup0.entry.get() + result

				topup0.entry.delete(0, END)
				topup0.entry.insert(0, _str) 				 

		elif self.current_section == 'Withdraw':

			result = callback.topup_click(event.x, event.y)

			if result == 'prev':
				withdraw0.entry.delete(0, END)
				self.go('prev')
				return

			result = callback.password_click(event.x, event.y)

			if result == False:

				return

			elif result == 'delete':

				_str = withdraw0.entry.get()[:len(withdraw0.entry.get())-1]

				withdraw0.entry.delete(0, END)
				withdraw0.entry.insert(0, _str) 

			else:

				_str = withdraw0.entry.get() + result

				withdraw0.entry.delete(0, END)
				withdraw0.entry.insert(0, _str) 

		elif self.current_section == 'Balance':

			result = callback.topup_click(event.x, event.y)

			if result == 'prev':
				self.go('prev')
				return

		elif self.current_section == 'Topup_success':

			result = callback.topup_success_click(event.x, event.y)

			if result == 'prev':
				self.go('prev')
				return

		elif self.current_section == 'Withdraw_success':

			result = callback.withdraw_success_click(event.x, event.y)

			if result == 'prev':
				self.go('prev')
				return

		elif self.current_section == 'Withdraw_alert':

			result = callback.withdraw_alert_click(event.x, event.y)

			if result == 'again':
				self.current_section = 'Withdraw'
				self.raise_window('Withdraw0')
				return
			
	
	def edit_password(self, result):

		if result == False:
			pass
		elif result == 'delete':
			self.password = self.password[:len(self.password)-1]
		else:
			self.password += result

		self.raise_window('Password%s' % len(self.password))

		if len(self.password) < 4:

			self.raise_window('Password%s' % len(self.password))

		else:

			self.raise_window('Password4')
			self.check_password()

	def check_password(self):

		encoded_card = open(self.card_href, 'r').read()

		card = coder.decode(self.password, encoded_card)

		try:
			card.index(self.secret_code)
			self.balance = float(card.split(' ')[1])

			self.encode_password = self.password

			self.current_section = 'Menu'
			self.password = ''
			self.raise_window('Menu0')
		except:
			self.current_section = 'Password_alert'
			self.password = ''
			self.raise_window('Password_alert0')

	def go(self, href):

		if href == 'prev':

			prev_section = self.prev_section

			self.current_section = prev_section
			self.raise_window(prev_section+str(0))

		elif href == 'home':

			self.encode_password = ''

			home_section = self.home_section

			self.current_section = home_section
			self.raise_window(home_section+str(0))

	def submit_value(self, event=None):

		if self.current_section == 'Topup':
			
			self.balance += float(topup0.entry.get())

			self.update_card()

			topup0.entry.delete(0, END)

			self.current_section = 'Topup_success'
			self.raise_window('Topup_success0')

		elif self.current_section == 'Withdraw':

			if self.balance >= float(withdraw0.entry.get()):

				self.balance -= float(withdraw0.entry.get())

				self.update_card()

				withdraw0.entry.delete(0, END)

				self.current_section = 'Withdraw_success'
				self.raise_window('Withdraw_success0')

			else:

				withdraw0.entry.delete(0, END)

				self.current_section = 'Withdraw_alert'
				self.raise_window('Withdraw_alert0')

	def update_card(self):

		data = coder.encode(self.encode_password, self.secret_code + ' ' + str(self.balance))
		open(self.card_href, 'w').write(data)

	def remove_focus(self, event):

		self.root.focus()

# import Image

from PIL import Image, ImageTk, ImageEnhance, ImageOps

class Window:

	frame = None
	label = None
	background = None
	entry = None

	def __init__(self, background_href, entry=False):

		self.frame = Frame(controller.root,
			width  = controller.width,
			height = controller.height)

		self.frame.grid(row=0, column=0, sticky='news')

		im = Image.open(controller.cwd+background_href)
		im = im.resize((controller.width,controller.height), Image.ANTIALIAS)
		self.background = ImageTk.PhotoImage(im)

		# self.background = PhotoImage(file=controller.cwd + background_href)

		label = Label(self.frame, image=self.background)
		label.place(x=0, y=0, relwidth=1, relheight=1)

		if entry == True:
			self.add_entry()
		elif entry == 'balance':
			self.add_balance()


	def add_entry(self):

		self.entry = Entry(self.frame,
			width=10,
			borderwidth=2,
			justify='center',
			font='Arial 25',
			validate='key')

		self.entry['validatecommand'] = (self.entry.register(self.testVal),'%P')
		self.entry.place(y=280, relx=0.5, anchor='center')
		# self.entry.bind('<Return>', controller.submit_value) 
		self.entry.bind('<FocusIn>', controller.remove_focus)

	def add_balance(self):

		self.balance_label = Label(self.frame, text='%.2f PLN' % controller.balance, font='Arial 25')
		self.balance_label.place(y=280, relx=0.5, anchor='center')

	def testVal(self, inStr):
		
		intStr = ''
		floatStr = ''

		try:
			floatStr = str(float(inStr))
		except:
			pass

		try:	
			intStr = str(int(inStr))
		except:
			pass

		if inStr == floatStr or inStr == intStr or inStr == floatStr[:len(floatStr)-1]:
			return True
		else:
			return False

controller = Controller()

password0 = Window('/screens/password/password0.png')
password1 = Window('/screens/password/password1.png')
password2 = Window('/screens/password/password2.png')
password3 = Window('/screens/password/password3.png')
password4 = Window('/screens/password/password4.png')
password_alert0 = Window('/screens/password/password-alert.png')

menu0 = Window('/screens/menu.png')
topup0 = Window('/screens/topup.png', True)
withdraw0 = Window('/screens/withdraw.png', True)
balance0 = Window('/screens/balance.png', 'balance')

topup_success0 = Window('/screens/topup-success.png')
withdraw_success0 = Window('/screens/withdraw-success.png')
withdraw_alert0 = Window('/screens/withdraw-alert.png')

app_windows = {
	'Password0': password0,
	'Password1': password1,
	'Password2': password2,
	'Password3': password3,
	'Password4': password4,
	'Password_alert0': password_alert0,

	'Menu0': menu0,
	'Topup0': topup0,
	'Withdraw0': withdraw0,
	'Balance0': balance0,

	'Topup_success0': topup_success0,
	'Withdraw_success0': withdraw_success0,
	'Withdraw_alert0': withdraw_alert0
}

controller.windows = app_windows
controller.raise_window('Password0')
controller.root.mainloop()


